# Recall — Android flashcards

A Kotlin/Jetpack Compose Android Studio starter project (minSdk 26) with a local JSON library, folder → chapter → deck organization, card model, due-card study flow, image import/compression utility, overlay bubble/service, notification RemoteInput quick-add, and Quick Settings tile.

## Build
1. Install Android Studio (Giraffe or newer) and Android SDK 35.
2. Open this folder (`Recall`) in Android Studio and allow Gradle sync.
3. Build > Make Project, then Run on an Android device (API 26+).
4. Grant notification permission when prompted. Tap **Overlay mode** and grant **Display over other apps** in Android settings to enable the floating bubble.
5. Add the **Add card** tile from Android Quick Settings edit mode.

## Storage
All library structure and card metadata are stored in the app-private `files/recall.json` file. Photos are stored as app-private JPEG files under `files/`; the JSON stores their paths. App, service, tile and notification receiver all use `RecallStore`, so updates are immediately visible to subsequent reads.

## Important implementation notes
- `PhotoTools.import()` applies EXIF rotation, scales the longest edge to 800px, and writes JPEG. Wire this helper to Android Photo Picker / `ActivityResultContracts.TakePicture` in a production UI.
- The overlay's native quick-add currently supports text fields and deck selection. The photo action opens the popup; camera/gallery URI capture UI should be connected to `PhotoTools.import()` for a complete photo workflow.
- The main Compose library supports creating/deleting folders, chapters and decks and starting study sessions. For a production release, add dedicated card editor screens, photo previews, persisted expand state, and robust migrations/backup.
- Android 13+ requires runtime notification permission. Android 14+ may require the foreground-service special-use declaration to be reviewed against current Play policy. Overlay permission is granted separately by the user.
- The simple scheduler uses 0/1/2/4/8/16-day steps. "Again" repeats the card at the end of the active in-memory session.
- This is an offline app; no network permission or account is used.


## Build from an Android phone (no PC)
1. Create/sign in to a GitHub account in your phone browser or GitHub app.
2. Create a new repository named `Recall` (public or private).
3. Upload the contents of this project, keeping the folder structure and hidden `.github` folder. If the mobile upload UI hides hidden files, create `.github/workflows/android-apk.yml` in GitHub's web editor and paste the workflow from this project.
4. Open the repository's **Actions** tab and allow workflows if GitHub asks. Run **Build Recall APK** using **Run workflow**, or push a commit to `main`.
5. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `Recall-debug-apk`. Extract it on your phone and tap `app-debug.apk` to install. You may need to allow your browser or file manager to install unknown apps.
6. This is a debug APK for personal testing, not a Play Store release. Keep the repository private if you do not want your source code public.
