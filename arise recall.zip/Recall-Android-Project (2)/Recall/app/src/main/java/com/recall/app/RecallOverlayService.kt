package com.recall.app

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import kotlin.math.max

class RecallOverlayService: Service() {
    private lateinit var wm: WindowManager
    private var bubble: View?=null
    private var panel: View?=null
    private val channel="recall_controls"
    override fun onBind(intent: Intent?)=null
    override fun onCreate() { super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; createChannel(); startForeground(7,notification()) }
    override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
        when(intent?.action) { "START" -> showBubble(); "POPUP" -> showQuickAdd(); "BUBBLE" -> showBubble(); "STOP" -> {remove(panel);remove(bubble);stopSelf()} }
        return START_STICKY
    }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"Recall controls",NotificationManager.IMPORTANCE_LOW)) }
    private fun notification(): Notification {
        val add=Intent(this,RecallReceiver::class.java).setAction("TEXT_ADD")
        val pi=PendingIntent.getBroadcast(this,1,add,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val remote=RemoteInput.Builder("card_text").setLabel("question | answer").build()
        val addAction=NotificationCompat.Action.Builder(android.R.drawable.ic_input_add,"Send",pi).addRemoteInput(remote).build()
        val photo=PendingIntent.getService(this,2,Intent(this,RecallOverlayService::class.java).setAction("POPUP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val bubblePi=PendingIntent.getService(this,3,Intent(this,RecallOverlayService::class.java).setAction("START"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("Recall • ${RecallStore.dueCount(this)} due").setContentText("Quick add: question | answer").setOngoing(true)
            .addAction(addAction).addAction(android.R.drawable.ic_menu_camera,"Add with photo",photo).addAction(android.R.drawable.ic_menu_view,"Bubble",bubblePi).build()
    }
    private fun params(): WindowManager.LayoutParams = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
    private fun showBubble(){
        if(!Settings.canDrawOverlays(this)||bubble!=null)return
        val v=TextView(this).apply { text="✦ ${RecallStore.dueCount(this@RecallOverlayService)}"; textSize=14f; setTextColor(0xffffffff.toInt()); setPadding(18,14,18,14); setBackgroundColor(0xff4f46e5.toInt()); elevation=12f }
        v.setOnTouchListener(DragTouch { showStudyPanel() }); v.setOnClickListener { showStudyPanel() }
        val p=params().apply{gravity=Gravity.TOP or Gravity.END;x=18;y=220}
        bubble=v; wm.addView(v,p)
    }
    private fun showStudyPanel(){
        remove(panel)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16);setBackgroundColor(0xff151d33.toInt())}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        top.addView(TextView(this).apply{text="Recall study";setTextColor(-1);textSize=18f},LinearLayout.LayoutParams(0,-2,1f))
        top.addView(btn("＋"){showQuickAdd()});top.addView(btn("—"){remove(panel)});top.addView(btn("×"){remove(panel)})
        box.addView(top)
        val due=RecallStore.allDecks(this).flatMap{it.cards}.filter{it.dueAt<=System.currentTimeMillis()}
        val card=due.firstOrNull()
        box.addView(TextView(this).apply{text=card?.question?.text ?: "No cards due";setTextColor(-1);textSize=17f;setPadding(0,20,0,16)})
        box.addView(btn("Show answer"){ if(card!=null) Toast.makeText(this@RecallOverlayService,card.answer.text,Toast.LENGTH_LONG).show() })
        box.addView(btn("Again"){ if(card!=null) RecallStore.review(this@RecallOverlayService,card.id,"Again"); remove(panel); updateNotification() })
        box.addView(btn("Good"){ if(card!=null) RecallStore.review(this@RecallOverlayService,card.id,"Good"); remove(panel); updateNotification() })
        panel=box; val p=params().apply{width=300;gravity=Gravity.CENTER}
        wm.addView(box,p)
    }
    private fun showQuickAdd(){
        remove(panel)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,16);setBackgroundColor(0xff151d33.toInt())}
        root.addView(TextView(this).apply{text="Quick add";textSize=18f;setTextColor(-1)})
        val decks=RecallStore.allDecks(this); val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,decks.map{it.name})
        root.addView(spinner)
        val q=EditText(this).apply{hint="Question";setTextColor(-1);setHintTextColor(0xff9aa6c2.toInt())}
        val a=EditText(this).apply{hint="Answer";setTextColor(-1);setHintTextColor(0xff9aa6c2.toInt())}
        root.addView(q);root.addView(a)
        var count=0; val status=TextView(this).apply{text="Added: 0";setTextColor(-1)};root.addView(status)
        root.addView(btn("Add card"){val deck=decks.getOrNull(spinner.selectedItemPosition);if(RecallStore.addCard(this,deck?.id,Side(q.text.toString()),Side(a.text.toString()))){count++;q.setText("");a.setText("");status.text="Added: $count";updateNotification()}else Toast.makeText(this,"Enter question and answer",Toast.LENGTH_SHORT).show()})
        root.addView(btn("Done"){remove(panel)})
        panel=root;wm.addView(root,params().apply{width=320;gravity=Gravity.CENTER})
    }
    private fun btn(label:String,action:()->Unit)=Button(this).apply{text=label;setOnClickListener{action()}}
    private fun remove(v:View?){if(v!=null)try{wm.removeView(v)}catch(_:Exception){};if(v===panel)panel=null;if(v===bubble)bubble=null}
    private fun updateNotification(){getSystemService(NotificationManager::class.java).notify(7,notification());bubble?.let{(it as TextView).text="✦ ${RecallStore.dueCount(this)}"}}
    override fun onDestroy(){remove(panel);remove(bubble);super.onDestroy()}
    private inner class DragTouch(val click:()->Unit):View.OnTouchListener{
        var sx=0f;var sy=0f;var ox=0;var oy=0;var moved=false
        override fun onTouch(v:View,e:android.view.MotionEvent):Boolean{val p=v.layoutParams as WindowManager.LayoutParams;when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;moved=false;return true};MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true;p.x=max(0,ox-dx);p.y=max(0,oy+dy);wm.updateViewLayout(v,p);return true};MotionEvent.ACTION_UP->{if(!moved)click();return true}};return true}
    }
}
class RecallReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.action=="TEXT_ADD"){val text=RemoteInput.getResultsFromIntent(i)?.getCharSequence("card_text")?.toString().orEmpty();val parts=text.split("|",limit=2);if(parts.size==2)RecallStore.addCard(c,RecallStore.lastDeck(c),Side(parts[0].trim()),Side(parts[1].trim()));c.startForegroundService(Intent(c,RecallOverlayService::class.java).setAction("START"))}}}
