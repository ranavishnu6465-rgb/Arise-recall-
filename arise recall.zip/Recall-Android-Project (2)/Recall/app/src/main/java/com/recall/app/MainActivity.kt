package com.recall.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy=Color(0xFF0B1020); private val Panel=Color(0xFF151D33); private val Indigo=Color(0xFF818CF8); private val Muted=Color(0xFF9AA6C2)
class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        setContent { RecallTheme { LibraryScreen(this) } }
    }
}
@Composable fun RecallTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme=darkColorScheme(background=Navy,surface=Panel,primary=Indigo,onBackground=Color.White,onSurface=Color.White), typography=Typography(), content=content) }

@Composable private fun LibraryScreen(activity: MainActivity) {
    var folders by remember { mutableStateOf(RecallStore.load(activity)) }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var dialogKind by remember { mutableStateOf("folder") }
    var selectedDeck by remember { mutableStateOf<String?>(null) }
    var study by remember { mutableStateOf(false) }
    fun persist() { RecallStore.save(activity,folders); folders=RecallStore.load(activity); refresh++ }
    Scaffold(containerColor=Navy, bottomBar={
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick={ if(Settings.canDrawOverlays(activity)) activity.startForegroundService(Intent(activity,RecallOverlayService::class.java).setAction("START")) else activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+activity.packageName))) }, modifier=Modifier.weight(1f).heightIn(min=44.dp)) { Text("Overlay mode") }
            Button(onClick={ dialogKind="folder"; dialog="New folder" }, modifier=Modifier.weight(1f).heightIn(min=44.dp)) { Icon(Icons.Default.Add,null); Text(" New") }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
            Spacer(Modifier.height(22.dp)); Text("Recall",fontSize=30.sp,color=Color.White); Text("Your memory, organized.",color=Muted)
            Spacer(Modifier.height(20.dp))
            LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(folders, key={it.id}) { folder ->
                    var open by remember(folder.id) { mutableStateOf(true) }
                    Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={open=!open}) { Icon(if(open) Icons.Default.ExpandMore else Icons.Default.ExpandLess,null) }
                            Text(folder.name,Modifier.weight(1f),color=Color.White)
                            IconButton(onClick={dialogKind="chapter:${folder.id}";dialog="New chapter"}) { Icon(Icons.Default.Add,null) }
                            IconButton(onClick={folders.remove(folder);persist()}) { Icon(Icons.Default.Delete,null,tint=Muted) }
                        }
                        if(open) folder.chapters.forEach { chapter ->
                            var chapterOpen by remember(chapter.id) { mutableStateOf(true) }
                            Column(Modifier.padding(start=18.dp)) {
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    IconButton(onClick={chapterOpen=!chapterOpen}) { Icon(if(chapterOpen) Icons.Default.ExpandMore else Icons.Default.ExpandLess,null) }
                                    Text(chapter.name,Modifier.weight(1f),color=Muted)
                                    IconButton(onClick={dialogKind="deck:${folder.id}:${chapter.id}";dialog="New deck"}) { Icon(Icons.Default.Add,null) }
                                    IconButton(onClick={folder.chapters.remove(chapter);persist()}) { Icon(Icons.Default.Delete,null,tint=Muted) }
                                }
                                if(chapterOpen) chapter.decks.forEach { deck ->
                                    val due=deck.cards.count { it.dueAt<=System.currentTimeMillis() }
                                    Column(Modifier.fillMaxWidth().padding(start=20.dp).padding(vertical=5.dp).background(Navy,RoundedCornerShape(12.dp)).clickable { selectedDeck=deck.id;study=true }.padding(12.dp)) {
                                        Row(verticalAlignment=Alignment.CenterVertically) {
                                            Text(deck.name,Modifier.weight(1f)); Text("${deck.cards.size} cards",color=Muted,fontSize=12.sp)
                                            if(due>0) Text("  $due due",color=Indigo,fontSize=12.sp)
                                            IconButton(onClick={chapter.decks.remove(deck);persist()}) { Icon(Icons.Default.Delete,null,tint=Muted) }
                                        }
                                        LinearProgressIndicator(progress={if(deck.cards.isEmpty()) 0f else deck.cards.count { it.reps>0 }.toFloat()/deck.cards.size}, modifier=Modifier.fillMaxWidth().height(4.dp),color=Indigo,trackColor=Panel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if(dialog!=null) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest={dialog=null},title={Text(dialog!!)},text={OutlinedTextField(value=name,onValueChange={name=it},placeholder={Text("Name")},singleLine=true)},confirmButton={
            TextButton(onClick={
                when { dialogKind=="folder" -> folders.add(Folder(name=name.ifBlank{"New folder"}))
                    dialogKind.startsWith("chapter:") -> folders.firstOrNull{it.id==dialogKind.substringAfter(":")}?.chapters?.add(Chapter(name=name.ifBlank{"New chapter"}))
                    dialogKind.startsWith("deck:") -> { val p=dialogKind.split(":"); folders.firstOrNull{it.id==p[1]}?.chapters?.firstOrNull{it.id==p[2]}?.decks?.add(Deck(name=name.ifBlank{"New deck"})) }
                }; persist(); dialog=null
            }) { Text("Create") }
        },dismissButton={TextButton(onClick={dialog=null}){Text("Cancel")}})
    }
    if(study) StudyDialog(activity,selectedDeck ?: "",onClose={study=false})
}
@Composable private fun StudyDialog(activity: MainActivity, deckId: String, onClose:()->Unit) {
    var cards by remember { mutableStateOf(RecallStore.allDecks(activity).firstOrNull{it.id==deckId}?.cards?.filter{it.dueAt<=System.currentTimeMillis()}?.toMutableList() ?: mutableListOf()) }
    var index by remember { mutableIntStateOf(0) }; var answer by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest=onClose,title={Text("Study")},text={
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
            if(cards.isEmpty() || index>=cards.size) Text("You're all caught up.")
            else {
                val c=cards[index]; Text(if(answer) c.answer.text else c.question.text)
                if(!answer) Button(onClick={answer=true},modifier=Modifier.fillMaxWidth().heightIn(min=44.dp)){Text("Show answer")}
                else Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("Again","Good","Easy").forEach { grade -> Button(onClick={RecallStore.review(activity,c.id,grade); if(grade=="Again") cards.add(c); index++; answer=false},modifier=Modifier.weight(1f).heightIn(min=44.dp),contentPadding=PaddingValues(4.dp)){Text(grade)} }
                }
            }
        }
    },confirmButton={TextButton(onClick=onClose){Text("Close")}})
}
