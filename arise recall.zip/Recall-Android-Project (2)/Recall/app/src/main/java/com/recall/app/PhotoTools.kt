package com.recall.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** Decode, orient from EXIF and scale the longest edge to 800px; stored as app-private JPEG. */
object PhotoTools {
    fun import(context: Context, uri: Uri): String? = try {
        val input=context.contentResolver.openInputStream(uri) ?: return null
        val bytes=input.use { it.readBytes() }
        val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }; BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
        var sample=1; while(maxOf(bounds.outWidth,bounds.outHeight)/sample>1600) sample*=2
        val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size,BitmapFactory.Options().apply{inSampleSize=sample}) ?: return null
        val exif=ExifInterface(bytes.inputStream()); val orientation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL)
        val degrees=when(orientation){ExifInterface.ORIENTATION_ROTATE_90->90f;ExifInterface.ORIENTATION_ROTATE_180->180f;ExifInterface.ORIENTATION_ROTATE_270->270f;else->0f}
        val oriented=if(degrees!=0f) Bitmap.createBitmap(bitmap,0,0,bitmap.width,bitmap.height,Matrix().apply{postRotate(degrees)},true) else bitmap
        val scale=minOf(1f,800f/maxOf(oriented.width,oriented.height))
        val final=if(scale<1f) Bitmap.createScaledBitmap(oriented,(oriented.width*scale).toInt(),(oriented.height*scale).toInt(),true) else oriented
        val out=File(context.filesDir,"photo_${System.currentTimeMillis()}.jpg"); FileOutputStream(out).use{final.compress(Bitmap.CompressFormat.JPEG,82,it)}
        out.absolutePath
    } catch (_:Exception) { null }
}
