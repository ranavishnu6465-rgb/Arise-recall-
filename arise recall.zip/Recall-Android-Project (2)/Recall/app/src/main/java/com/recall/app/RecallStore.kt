package com.recall.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Single source of truth: files/recall.json. All app components use this repository. */
object RecallStore {
    private fun file(c: Context) = File(c.applicationContext.filesDir, "recall.json")
    @Synchronized fun load(c: Context): MutableList<Folder> {
        val f=file(c)
        if (!f.exists()) {
            val seed = mutableListOf(Folder(name="My Library", chapters= mutableListOf(Chapter(name="Getting started", decks= mutableListOf(Deck(name="Sample deck"))))))
            save(c, seed); return seed
        }
        return try {
            val a=JSONArray(f.readText())
            mutableListOf<Folder>().also { out -> for(i in 0 until a.length()) out.add(Folder.from(a.getJSONObject(i))) }
        } catch (_: Exception) { mutableListOf(Folder(name="My Library")) }
    }
    @Synchronized fun save(c: Context, folders: List<Folder>) {
        val a=JSONArray(); folders.forEach { a.put(it.json()) }
        val f=file(c); val tmp=File(f.parentFile, "recall.json.tmp")
        tmp.writeText(a.toString(2)); if (!tmp.renameTo(f)) { f.writeText(a.toString(2)); tmp.delete() }
    }
    fun allDecks(c: Context): List<Deck> = load(c).flatMap { it.chapters }.flatMap { it.decks }
    fun dueCount(c: Context, now: Long = System.currentTimeMillis()) = allDecks(c).sumOf { d -> d.cards.count { it.dueAt <= now } }
    fun addCard(c: Context, deckId: String?, q: Side, a: Side): Boolean {
        if (q.text.isBlank() && q.photo == null || a.text.isBlank() && a.photo == null) return false
        val fs=load(c); val deck=fs.flatMap { it.chapters }.flatMap { it.decks }.firstOrNull { it.id == deckId }
            ?: fs.flatMap { it.chapters }.flatMap { it.decks }.firstOrNull() ?: return false
        deck.cards.add(FlashCard(question=q, answer=a)); save(c,fs); c.getSharedPreferences("recall",0).edit().putString("lastDeck",deck.id).apply(); return true
    }
    fun lastDeck(c: Context) = c.getSharedPreferences("recall",0).getString("lastDeck", null)
    fun review(c: Context, cardId: String, grade: String) {
        val fs=load(c); val card=fs.flatMap { it.chapters }.flatMap { it.decks }.flatMap { it.cards }.firstOrNull { it.id==cardId } ?: return
        val gaps=listOf(0,1,2,4,8,16)
        val step=when(grade) { "Again" -> 0; "Good" -> (card.interval+1).coerceAtMost(5); else -> (card.interval+2).coerceAtMost(5) }
        card.interval=step; card.reps++; card.dueAt=System.currentTimeMillis()+gaps[step]*24L*60*60*1000
        save(c,fs)
    }
}
